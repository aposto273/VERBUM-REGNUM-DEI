import { ReactNode } from "react";

export const MainLayout = ({ children }: { children: ReactNode }) => {
  return (
    <div>
      <header className="p-4 border-b flex justify-between">
        <h1 className="font-bold">Company</h1>
        <nav className="space-x-4">
          <a href="/">Home</a>
          <a href="/about">About</a>
          <a href="/services">Services</a>
          <a href="/contact">Contact</a>
        </nav>
      </header>

      <main>{children}</main>

      <footer className="text-center p-4 border-t text-sm text-gray-500">
        © 2026 Company Profile
      </footer>
    </div>
  );
};