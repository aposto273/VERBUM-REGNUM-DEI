import { Section } from "@/components/common/Section";
import {
  BadgeCheck,
  Clock,
  Settings,
  DollarSign,
} from "lucide-react";

const usp = [
  {
    title: "Berpengalaman & Terpercaya",
    desc: "Lebih dari 8 tahun pengalaman dalam IT Infrastructure, Network, dan Server Management untuk berbagai kebutuhan bisnis.",
    icon: BadgeCheck,
  },
  {
    title: "Support Cepat & Responsif",
    desc: "Tim kami siap membantu dengan respon cepat untuk memastikan sistem Anda tetap berjalan tanpa hambatan.",
    icon: Clock,
  },
  {
    title: "Solusi Fleksibel & Scalable",
    desc: "Setiap solusi dirancang sesuai kebutuhan bisnis Anda dan dapat berkembang seiring pertumbuhan perusahaan.",
    icon: Settings,
  },
  {
    title: "Harga Transparan",
    desc: "Kami memberikan penawaran yang jelas, kompetitif, dan tanpa biaya tersembunyi.",
    icon: DollarSign,
  },
];

export const AboutSection = () => {
  return (
        <Section
      title="Kenapa Harus Kami?"
    >
      <p className="text-center text-gray-600 mb-6">
        Kami tidak hanya menyediakan layanan IT, tetapi juga solusi yang tepat untuk keberlangsungan bisnis Anda.
      </p>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {usp.map((item, i) => {
          const Icon = item.icon;

          return (
            <div
              key={i}
              className="group p-6 rounded-2xl border bg-white hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              {/* ICON */}
              <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-blue-100 text-blue-600 mb-4 group-hover:bg-blue-600 group-hover:text-white transition">
                <Icon size={24} />
              </div>

              {/* TITLE */}
              <h3 className="font-semibold text-lg mb-2">
                {item.title}
              </h3>

              {/* DESC */}
              <p className="text-gray-500 text-sm leading-relaxed">
                {item.desc}
              </p>
            </div>
          );
        })}
      </div>
    </Section>
  );
};