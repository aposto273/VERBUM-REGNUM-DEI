import { Mail, Phone, MapPin } from "lucide-react";

export const Footer = () => {
  return (
    <section id="footer">
        <footer className="bg-gray-900 text-gray-300 pt-16 pb-8 px-6">
            <div className="max-w-6xl mx-auto grid md:grid-cols-4 gap-10">
                
                {/* BRAND */}
                <div>
                <h2 className="text-white font-bold text-xl mb-4">
                    Empat.Karat<span className="text-blue-600">.id</span>
                </h2>
                <p className="text-sm text-gray-400 leading-relaxed">
                    Solusi IT profesional meliputi network, server, CCTV, dan
                    pengembangan sistem untuk mendukung operasional bisnis Anda.
                </p>
                </div>

                {/* LAYANAN */}
                <div>
                <h3 className="text-white font-semibold mb-4">Services</h3>
                <ul className="space-y-2 text-sm">
                    <li>IT Infrastructure & Network</li>
                    <li>Server & Deployment</li>
                    <li>CCTV (NVR & IP Camera)</li>
                    <li>IT Support & Troubleshooting</li>
                </ul>
                </div>

                {/* NAVIGATION */}
                <div>
                <h3 className="text-white font-semibold mb-4">Navigasi</h3>
                <ul className="space-y-2 text-sm">
                    <li>
                    <a href="#" className="hover:text-white transition">
                        Home
                    </a>
                    </li>
                    <li>
                    <a href="#services" className="hover:text-white transition">
                        Services
                    </a>
                    </li>
                    <li>
                    <a href="#contact" className="hover:text-white transition">
                        Contact
                    </a>
                    </li>
                </ul>
                </div>

                {/* KONTAK */}
                <div>
                <h3 className="text-white font-semibold mb-4">Kontak</h3>
                <ul className="space-y-3 text-sm">
                    <li className="flex items-start gap-2">
                    <MapPin size={16} className="mt-1" />
                    <span>Indonesia</span>
                    </li>
                    <li className="flex items-center gap-2">
                    <Phone size={16} />
                    <span>+62 897-2247-571</span>
                    </li>
                    <li className="flex items-center gap-2">
                    <Mail size={16} />
                    <span>info@empatkarat.my.id</span>
                    </li>
                </ul>
                </div>
            </div>

            {/* BOTTOM */}
            <div className="border-t border-gray-800 mt-10 pt-6 text-center text-sm text-gray-500">
                © {new Date().getFullYear()} EmpatKarat.id. All rights reserved.
            </div>
        </footer>
    </section>
  );
};