import { Button } from "@/components/ui/button";

export const Hero = () => {
  return (
    <section className="relative py-32 px-6 text-center overflow-hidden">
      
      {/* BASE GRADIENT */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-white via-blue-50 to-white" />

      {/* GLOW EFFECT */}
      <div className="absolute top-[-100px] left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-blue-500/20 rounded-full blur-3xl" />

      {/* SECOND GLOW */}
      <div className="absolute bottom-[-150px] right-[-100px] w-[400px] h-[400px] bg-indigo-500/20 rounded-full blur-3xl" />

      {/* GRID OVERLAY (tech feel) */}
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#e5e7eb_1px,transparent_1px),linear-gradient(to_bottom,#e5e7eb_1px,transparent_1px)] bg-[size:40px_40px] opacity-30" />

      {/* CONTENT */}
      <div className="max-w-3xl mx-auto relative z-10">
        
        {/* Badge */}
        <span className="inline-block mb-4 text-sm px-4 py-1 rounded-full bg-blue-100 text-blue-600 font-medium">
          🚀 IT Solutions & Digital Services
        </span>

        {/* Headline */}
        <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
          Solusi IT{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-500">
            Profesional
          </span>{" "}
          untuk Bisnis Modern
        </h1>

        {/* Subheadline */}
        <p className="text-gray-500 text-lg md:text-xl mb-8">
          Kami membantu bisnis Anda berkembang melalui layanan{" "}
          <span className="font-medium text-gray-700">
            Network, Server, dan Development
          </span>{" "}
          yang handal dan scalable.
        </p>

        {/* CTA */}
        <div className="flex justify-center gap-4 flex-wrap">
          <Button
            size="lg"
            className="px-8"
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
          >
            Hubungi Kami
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="px-8"
            onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}
          >
            Lihat Layanan
          </Button>
        </div>
      </div>
    </section>
  );
};