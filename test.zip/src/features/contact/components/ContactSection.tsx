import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export const ContactSection = () => {
  const phone = "628972247571"; // GANTI NOMOR KAMU
  const message = encodeURIComponent(
    "Halo, saya ingin konsultasi terkait layanan IT (network / server / CCTV)."
  );

  const waLink = `https://wa.me/${phone}?text=${message}`;

  return (
     <section id="contact"  className="py-24 px-6 text-center relative overflow-hidden">
      {/* Background */}
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-blue-600 to-indigo-600" />
        <div className="absolute inset-0 -z-10 bg-black/20" />

        <div className="max-w-2xl mx-auto text-white">
          {/* TITLE */}
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Butuh Solusi IT untuk Bisnis Anda?
          </h2>

          {/* DESC */}
          <p className="mb-8 text-white/80">
            Konsultasikan kebutuhan Anda sekarang. Kami siap membantu
            mulai dari network, server, hingga troubleshooting.
          </p>

          {/* BUTTON */}
          <a href={waLink} target="_blank" rel="noopener noreferrer">
            <Button
              size="lg"
              className="bg-white text-blue-600 hover:bg-gray-100 px-8"
            >
              <MessageCircle className="mr-2" size={20} />
              Konsultasi via WhatsApp
            </Button>
          </a>
        </div>
      </section>
  );
};